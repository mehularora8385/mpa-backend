const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

router.post("/forgot-password", authController.forgotPassword);
router.post("/change-password", authController.changePassword);

module.exports = router;
